pour compiler le projet, il faut faire la commande "gcc main.c cdataframe.c -o programme" sur la ligne de commande

ensuite il faut écrire "./programme" pour l'exécuter