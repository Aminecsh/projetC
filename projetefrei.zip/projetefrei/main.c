#include <stdio.h>
#include <stdlib.h>
#include "cdataframe.h"

COLUMN *create_column(char *title) {
	COLUMN *to_return = malloc(sizeof(COLUMN));
	if (to_return == NULL)
		return NULL;
	to_return->title = title;
	to_return->logical_size = 0;
	to_return->physical_size = 0;
	to_return->data = NULL;
	return to_return;
}

int insert_value(COLUMN *col, int value) {
	if (col == NULL)
		return 0;
	if (col->data == NULL) {
		col->data = malloc(sizeof(int) * REALOC_SIZE);
		col->physical_size = REALOC_SIZE;
		if (col->data == NULL)
			return 0;
	}
	else if (col->logical_size == col->physical_size) {
		col->data = realloc(col->data, sizeof(int) * (col->physical_size + REALOC_SIZE));
		col->physical_size += REALOC_SIZE;
		if (col->data == NULL)
			return 0;
	}
	col->data[col->logical_size] = value;
	col->logical_size += 1;
	return 1;
}

void delete_column(COLUMN **col) {
	free((*col)->data);
	free(*col);
}

void print_col(COLUMN* col) {
	for (int i = 0; i < col->logical_size; i++)
		printf("[%d] %d\n", i, col->data[i]);
}

int number_of_occurences(COLUMN *col, int x) {
	int count = 0;
	for (int i = 0; i < col->logical_size; i++)
		if (col->data[i] == x)
			count++;
	return count;
}

int get_value(COLUMN *col, int index) {
	return (col->data[index]);
}

int number_of_higher_occurences(COLUMN *col, int x) {
	int count = 0;
	for (int i = 0; i < col->logical_size; i++)
		if (col->data[i] > x)
			count++;
	return count;
}

int number_of_lower_occurences(COLUMN *col, int x) {
	int count = 0;
	for (int i = 0; i < col->logical_size; i++)
		if (col->data[i] < x)
			count++;
	return count;
}

int number_of_equal_occurences(COLUMN *col, int x) {
	return number_of_occurences(col, x);
}

int main(void) {
	CDataframe* dataframe1 = create_cdataframe();
	if (dataframe1 == NULL)
		return 1;
	fill_cdataframe_user_input(dataframe1);

	CDataframe* dataframe2 = create_cdataframe();
	if (dataframe2 == NULL)
		return 1;
	fill_cdataframe_hardcode(dataframe2);

	return 0;
}
