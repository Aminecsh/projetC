#ifndef MYLIBRARY_H
#define MYLIBRARY_H

#define REALOC_SIZE 256

typedef struct COLUMN {
	char *title;
	int physical_size;
	int logical_size;
	int	*data;
} COLUMN;

typedef struct CDataframe {
	char *title;
	int physical_size;
	int logical_size;
	COLUMN* columns;
} CDataframe;

COLUMN *create_column(char *title);

CDataframe *create_cdataframe();
int	fill_cdataframe_user_input(CDataframe* to_fill);
int	fill_cdataframe_hardcode(CDataframe* to_fill);


#endif //MYLIBRARY_H
