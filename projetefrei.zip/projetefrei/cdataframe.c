#include "cdataframe.h"
#include <stdlib.h>
#include <stdio.h>


CDataframe *create_cdataframe() {
	CDataframe *to_return = malloc(sizeof(CDataframe));
	if (to_return == NULL)
		return NULL;
	to_return->title = "example";
	to_return->logical_size = 0;
	to_return->physical_size = 0;
	to_return->columns = NULL;
	return to_return;
}

int	fill_cdataframe_user_input(CDataframe* to_fill) {
	int number_of_columns;
	printf("Saisissez le nombre de colonnes voulues\n");
	scanf("%d", &number_of_columns);
	to_fill->logical_size = number_of_columns;
	to_fill->columns = malloc(sizeof(COLUMN) * number_of_columns);
	if (to_fill->columns == NULL)
		return 0;
	return 1;
}

int	fill_cdataframe_hardcode(CDataframe* to_fill) {
	to_fill->physical_size = 1;
	to_fill->logical_size = 1;
	to_fill->columns = create_column("example");
	if (to_fill->columns == NULL)
		return 0;
	return 1;
}

void	display_cdataframe(CDataframe* to_display) {
	for (int i = 0; i < to_display->logical_size; i++) {
		printf("titre colonne %d: %s\n", i, to_display->columns[i].title);
		printf("taille logique colonne %d: %d\n", i, to_display->columns[i].logical_size);
		printf("taille physique colonne %d: %d\n", i, to_display->columns[i].physical_size);
		printf("Tableau colonne %d : ", i);
		for (int j = 0; j < to_display->columns[i].logical_size; j++) {
			printf("%d ", to_display->columns[i].data[j]);
		}
		printf("\n");
	}
}